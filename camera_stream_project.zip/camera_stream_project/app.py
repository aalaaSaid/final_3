from flask import Flask, render_template
from flask_socketio import SocketIO

app = Flask(__name__)
socketio = SocketIO(app)


@app.route('/')
def index():
    return render_template('index.html')


@socketio.on('video_frame')
def handle_video_frame(frame):
    # Process the received frame here
    print("Received frame:", frame[:50])  # Example: Print first 50 characters


if __name__ == '__main__':
    socketio.run(app)
